/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

public class TipoUsuarioHasPermiso {
    private int tipoUsuarioIdTipoUsuario;
    private int permisoIdPermisos;

    public TipoUsuarioHasPermiso() {
    }

    public TipoUsuarioHasPermiso(int tipoUsuarioIdTipoUsuario, int permisoIdPermisos) {
        this.tipoUsuarioIdTipoUsuario = tipoUsuarioIdTipoUsuario;
        this.permisoIdPermisos = permisoIdPermisos;
    }

    public int getTipoUsuarioIdTipoUsuario() {
        return tipoUsuarioIdTipoUsuario;
    }

    public void setTipoUsuarioIdTipoUsuario(int tipoUsuarioIdTipoUsuario) {
        this.tipoUsuarioIdTipoUsuario = tipoUsuarioIdTipoUsuario;
    }

    public int getPermisoIdPermisos() {
        return permisoIdPermisos;
    }

    public void setPermisoIdPermisos(int permisoIdPermisos) {
        this.permisoIdPermisos = permisoIdPermisos;
    }
}