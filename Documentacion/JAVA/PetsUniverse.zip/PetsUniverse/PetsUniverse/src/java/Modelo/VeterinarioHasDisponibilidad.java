/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

public class VeterinarioHasDisponibilidad {
    private int veterinarioIdVeterinario;
    private int disponibilidadIdDisponibilidad;

    public VeterinarioHasDisponibilidad() {
    }

    public VeterinarioHasDisponibilidad(int veterinarioIdVeterinario, int disponibilidadIdDisponibilidad) {
        this.veterinarioIdVeterinario = veterinarioIdVeterinario;
        this.disponibilidadIdDisponibilidad = disponibilidadIdDisponibilidad;
    }

    public int getVeterinarioIdVeterinario() {
        return veterinarioIdVeterinario;
    }

    public void setVeterinarioIdVeterinario(int veterinarioIdVeterinario) {
        this.veterinarioIdVeterinario = veterinarioIdVeterinario;
    }

    public int getDisponibilidadIdDisponibilidad() {
        return disponibilidadIdDisponibilidad;
    }

    public void setDisponibilidadIdDisponibilidad(int disponibilidadIdDisponibilidad) {
        this.disponibilidadIdDisponibilidad = disponibilidadIdDisponibilidad;
    }
}