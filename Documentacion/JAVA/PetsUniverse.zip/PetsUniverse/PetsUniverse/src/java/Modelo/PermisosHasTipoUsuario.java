/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

public class PermisosHasTipoUsuario {
    private int permisosIdPermisos;
    private int tipoUsuarioIdTipoUsuario;

    public PermisosHasTipoUsuario() {
    }

    public PermisosHasTipoUsuario(int permisosIdPermisos, int tipoUsuarioIdTipoUsuario) {
        this.permisosIdPermisos = permisosIdPermisos;
        this.tipoUsuarioIdTipoUsuario = tipoUsuarioIdTipoUsuario;
    }

    public int getPermisosIdPermisos() {
        return permisosIdPermisos;
    }

    public void setPermisosIdPermisos(int permisosIdPermisos) {
        this.permisosIdPermisos = permisosIdPermisos;
    }

    public int getTipoUsuarioIdTipoUsuario() {
        return tipoUsuarioIdTipoUsuario;
    }

    public void setTipoUsuarioIdTipoUsuario(int tipoUsuarioIdTipoUsuario) {
        this.tipoUsuarioIdTipoUsuario = tipoUsuarioIdTipoUsuario;
    }
}