package Controlador;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    private Connection conn;
    private String driver = "com.mysql.cj.jdbc.Driver";
    private String user = "root";
    private String password = "";
    private String baseDatos = "PetsUniverse";
    private String url = "jdbc:mysql://localhost:3307/" + baseDatos + "?useTimezone=UTC";

    public Conexion() {
        conn = null;

        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, user, password);

            if (conn == null) {
                System.out.println("No se establecio la conexión." + url);
            } else {
                System.out.println("Conexión exitosa." + url);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Connection getConn() {
        return conn;
    }
}