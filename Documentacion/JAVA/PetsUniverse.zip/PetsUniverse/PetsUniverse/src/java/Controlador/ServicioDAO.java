/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Servicio;
import Modelo.TipoServicio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServicioDAO {

    private Conexion conect = new Conexion();

    // LISTAR SERVICIOS CON JOIN A TIPO_SERVICIO
    public List<Servicio> listarServicios() {
        List<Servicio> lista = new ArrayList<>();
        String querySql = "SELECT s.id_servicio, s.descripcion, s.precio, s.duracion, "
                + "s.tipo_servicio_id_tipo_servicio, ts.descripcion AS tipo_descripcion "
                + "FROM servicio s "
                + "INNER JOIN tipo_servicio ts ON s.tipo_servicio_id_tipo_servicio = ts.id_tipo_servicio";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Servicio servicio = new Servicio();
                servicio.setIdServicio(rs.getInt("id_servicio"));
                servicio.setNombreServicio(rs.getString("nombre_servicio"));
                servicio.setDescripcion(rs.getString("descripcion"));
                servicio.setPrecio(rs.getDouble("precio"));
                servicio.setDuracion(rs.getInt("duracion"));
                servicio.setTipoServicioIdTipoServicio(rs.getInt("tipo_servicio_id_tipo_servicio"));

                // Objeto TipoServicio anidado para mostrar la descripción de la categoría
                TipoServicio tipo = new TipoServicio();
                tipo.setIdTipoServicio(rs.getInt("tipo_servicio_id_tipo_servicio"));
                tipo.setDescripcion(rs.getString("tipo_descripcion"));
                servicio.setTipoServicio(tipo);

                lista.add(servicio);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar servicios: " + e.getMessage());
        }
        return lista;
    }

    // CONSULTAR SERVICIO POR ID CON JOIN
    public Servicio consultarServicioPorId(int id) {
        Servicio servicio = null;
        String querySql = "SELECT s.id_servicio, s.nombre_servicio, s.descripcion, s.precio, s.duracion, "
                + "s.tipo_servicio_id_tipo_servicio, ts.descripcion AS tipo_descripcion "
                + "FROM servicio s "
                + "INNER JOIN tipo_servicio ts ON s.tipo_servicio_id_tipo_servicio = ts.id_tipo_servicio "
                + "WHERE s.id_servicio = ?";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                servicio = new Servicio();
                servicio.setIdServicio(rs.getInt("id_servicio"));
                servicio.setNombreServicio(rs.getString("nombre_servicio"));
                servicio.setDescripcion(rs.getString("descripcion"));
                servicio.setPrecio(rs.getDouble("precio"));
                servicio.setDuracion(rs.getInt("duracion"));
                servicio.setTipoServicioIdTipoServicio(rs.getInt("tipo_servicio_id_tipo_servicio"));

                TipoServicio tipo = new TipoServicio();
                tipo.setIdTipoServicio(rs.getInt("tipo_servicio_id_tipo_servicio"));
                tipo.setDescripcion(rs.getString("tipo_descripcion"));
                servicio.setTipoServicio(tipo);
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar servicio por ID: " + e.getMessage());
        }
        return servicio;
    }

    public boolean insertarServicio(Servicio servicio) {
        boolean inserto = false;
        String querySql = "INSERT INTO servicio (nombre_servicio, descripcion, precio, duracion, tipo_servicio_id_tipo_servicio) "
                + "VALUES (?, ?, ?, ?, ?)";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setString(1, servicio.getNombreServicio());
            ps.setString(2, servicio.getDescripcion());
            ps.setDouble(3, servicio.getPrecio());
            ps.setInt(4, servicio.getDuracion());
            ps.setInt(5, servicio.getTipoServicioIdTipoServicio());

            if (ps.executeUpdate() > 0) {
                inserto = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al insertar servicio: " + e.getMessage());
        }
        return inserto;
    }

    public boolean actualizarServicio(Servicio servicio) {
        boolean actualizo = false;
        String querySql = "UPDATE servicio SET nombre_servicio = ?, descripcion = ?, precio = ?, duracion = ?, "
                + "tipo_servicio_id_tipo_servicio = ? WHERE id_servicio = ?";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setString(1, servicio.getNombreServicio());
            ps.setString(2, servicio.getDescripcion());
            ps.setDouble(3, servicio.getPrecio());
            ps.setInt(4, servicio.getDuracion());
            ps.setInt(5, servicio.getTipoServicioIdTipoServicio());
            ps.setInt(6, servicio.getIdServicio());

            if (ps.executeUpdate() > 0) {
                actualizo = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar servicio: " + e.getMessage());
        }
        return actualizo;
    }

    public boolean eliminarServicio(int id) {
        boolean elimino = false;
        String querySql = "DELETE FROM servicio WHERE id_servicio = ?";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);

            if (ps.executeUpdate() > 0) {
                elimino = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar servicio: " + e.getMessage());
        }
        return elimino;
    }
}