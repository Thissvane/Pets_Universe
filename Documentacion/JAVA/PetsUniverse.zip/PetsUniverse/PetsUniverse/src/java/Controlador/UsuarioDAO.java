package Controlador;

import Modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Date;

public class UsuarioDAO {

    private Conexion conect = new Conexion();

    public Usuario consultarUsuario(String email) {
        Usuario miUsuario = null;
        Connection conn = conect.getConn();

        try {
            String querySql = "SELECT id_usuario, nombre, apellido, fecha_nacimiento, num_documento, num_telefono, email, "
                    + "fecha_vencimiento_clave, autorizacion_datos, estado, tipo_documento_id_tipo_documento, tipo_usuario_id_tipo_usuario, clave "
                    + "FROM usuario WHERE email = ?";

            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                miUsuario = new Usuario();
                miUsuario.setIdUsuario(rs.getInt("id_usuario"));
                miUsuario.setNombre(rs.getString("nombre"));
                miUsuario.setApellido(rs.getString("apellido")); 
                miUsuario.setFechaNacimiento(rs.getDate("fecha_nacimiento").toLocalDate());
                miUsuario.setNumDocumento(rs.getString("num_documento")); 
                miUsuario.setNumTelefono(rs.getString("num_telefono"));
                miUsuario.setEmail(rs.getString("email"));
                miUsuario.setClave(rs.getString("clave"));
                miUsuario.setFechaVencimientoClave(rs.getDate("fecha_vencimiento_clave").toLocalDate());
                miUsuario.setAutorizacionDatos(rs.getBoolean("autorizacion_datos"));
                miUsuario.setEstado(rs.getBoolean("estado"));
                miUsuario.setTipoDocumentoIdTipoDocumento(rs.getInt("tipo_documento_id_tipo_documento"));
                miUsuario.setTipoUsuarioIdTipoUsuario(rs.getInt("tipo_usuario_id_tipo_usuario")); 
            }
            return miUsuario;

        } catch (SQLException e) {
            System.out.println("Error al consultar usuario: " + e.getMessage());
            return miUsuario;
        }
    }

    public boolean InsertarUsuario(Usuario miUsuario) {
        boolean insertar = false;
        Connection conn = conect.getConn();

        try {
            String querySql = "INSERT INTO usuario (nombre, apellido, fecha_nacimiento, num_documento, num_telefono, email, clave, fecha_vencimiento_clave, autorizacion_datos, estado,  tipo_documento_id_tipo_documento, tipo_usuario_id_tipo_usuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setString(1, miUsuario.getNombre());
            ps.setString(2, miUsuario.getApellido());
            ps.setDate(3, Date.valueOf(miUsuario.getFechaNacimiento()));
            ps.setString(4, miUsuario.getNumDocumento());
            ps.setString(5, miUsuario.getNumTelefono());
            ps.setString(6, miUsuario.getEmail());
            ps.setString(7, miUsuario.getClave());
            ps.setDate(8, Date.valueOf(miUsuario.getFechaVencimientoClave()));
            ps.setBoolean(9, miUsuario.isAutorizacionDatos()); 
            ps.setBoolean(10, miUsuario.isEstado());
            ps.setInt(11, miUsuario.getTipoDocumentoIdTipoDocumento());
            ps.setInt(12, miUsuario.getTipoUsuarioIdTipoUsuario()); 

            ps.executeUpdate();
            insertar = true;
            System.out.println("Dato Insertado correctamente");

        } catch (SQLException e) {
            System.out.println("Error al insertar Usuario: " + e.getMessage());
        }
        return insertar;
    }

    public boolean ActualizarUsuario(Usuario miUsuario) {
        boolean actualizar = false;
        Connection conn = conect.getConn();

        try {
            String querySql = "UPDATE usuario SET nombre = ?, apellido = ?, fecha_nacimiento = ?, num_documento = ?, num_telefono = ?, email = ?, clave = ?, fecha_vencimiento_clave = ?, autorizacion_datos = ?, estado?, tipo_documento_id_tipo_documento = ?, tipo_usuario_id_tipo_usuario = ? WHERE id_usuario = ?";

            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setString(1, miUsuario.getNombre());
            ps.setString(2, miUsuario.getApellido());
            ps.setDate(3, Date.valueOf(miUsuario.getFechaNacimiento()));
            ps.setString(4, miUsuario.getNumDocumento());
            ps.setString(5, miUsuario.getNumTelefono());
            ps.setString(6, miUsuario.getEmail());
            ps.setString(7, miUsuario.getClave());
            ps.setDate(8, Date.valueOf(miUsuario.getFechaVencimientoClave()));
            ps.setBoolean(9, miUsuario.isAutorizacionDatos());
            ps.setBoolean(10, miUsuario.isEstado());
            ps.setInt(11, miUsuario.getTipoDocumentoIdTipoDocumento());
            ps.setInt(12, miUsuario.getTipoUsuarioIdTipoUsuario());
            ps.setInt(13, miUsuario.getIdUsuario());

            if (ps.executeUpdate() > 0) {
                actualizar = true;
                System.out.println("Dato Actualizado correctamente");
            }

        } catch (SQLException e) {
            System.out.println("Error al actualizar Usuario: " + e.getMessage());
        }
        return actualizar;
    }
    
    public boolean InactivarUsuario(int id) {
        boolean inactivar = false;

        String querySql = "UPDATE Usuario SET estado = 0 WHERE id_usuario = ?";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                inactivar = true;
            }

        } catch (Exception e) {
            System.out.println("Error al inactivar usuario");
        }
        return inactivar;
    }

    public boolean ActivarUsuario(int id) {
        boolean activar = true;

        String querySql = "UPDATE Usuario SET estado = 1 WHERE id_usuario = ?";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);
            if (ps.executeUpdate() > 1) {
                activar = true;
            }

        } catch (Exception e) {
            System.out.println("Error al activar usuario");
        }
        return activar;
    }
    
    public boolean EliminarUsuario(int id) {
        boolean eliminar = false;
        String querySql = "DELETE FROM usuario WHERE id_usuario = ?";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                eliminar = true;
                System.out.println("Usuario eliminado correctamente");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar usuario: " + e.getMessage());
        }
        return eliminar;
    }
}
