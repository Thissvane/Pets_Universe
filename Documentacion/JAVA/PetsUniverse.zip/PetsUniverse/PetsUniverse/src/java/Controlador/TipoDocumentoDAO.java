package Controlador;

import Modelo.TipoDocumento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoDocumentoDAO {

    private Conexion conect = new Conexion();

    // 1. LISTAR TODOS LOS TIPOS DE DOCUMENTO (Para combos y selects)
    public List<TipoDocumento> listarTiposDocumento() {
        List<TipoDocumento> lista = new ArrayList<>();
        String querySql = "SELECT id_tipo_documento, sigla, descripcion FROM tipo_documento";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                TipoDocumento td = new TipoDocumento();
                td.setIdTipoDocumento(rs.getInt("id_tipo_documento"));
                td.setSigla(rs.getString("sigla"));
                td.setDescripcion(rs.getString("descripcion"));

                lista.add(td);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar tipos de documento: " + e.getMessage());
        }
        return lista;
    }

    // 2. CONSULTAR UN TIPO DE DOCUMENTO POR ID
    public TipoDocumento consultarTipoDocumentoPorId(int id) {
        TipoDocumento td = null;
        String querySql = "SELECT id_tipo_documento, sigla, descripcion FROM tipo_documento WHERE id_tipo_documento = ?";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                td = new TipoDocumento();
                td.setIdTipoDocumento(rs.getInt("id_tipo_documento"));
                td.setSigla(rs.getString("sigla"));
                td.setDescripcion(rs.getString("descripcion"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar tipo de documento por ID: " + e.getMessage());
        }
        return td;
    }
}