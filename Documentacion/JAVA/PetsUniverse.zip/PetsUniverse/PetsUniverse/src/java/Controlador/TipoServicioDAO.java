package Controlador;

import Modelo.TipoServicio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoServicioDAO {

    private Conexion conect = new Conexion();

    // LISTAR TODOS LOS TIPOS DE SERVICIO
    public List<TipoServicio> listarTiposServicio() {
        List<TipoServicio> lista = new ArrayList<>();
        String querySql = "SELECT id_tipo_servicio, descripcion FROM tipo_servicio";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                TipoServicio tipo = new TipoServicio();
                tipo.setIdTipoServicio(rs.getInt("id_tipo_servicio"));
                tipo.setDescripcion(rs.getString("descripcion"));
                
                lista.add(tipo);
            }
        } catch (SQLException e) {
            System.out.println("Error al listar tipos de servicio: " + e.getMessage());
        }
        return lista;
    }

    public TipoServicio consultarTipoServicioPorId(int id) {
        TipoServicio tipo = null;
        String querySql = "SELECT id_tipo_servicio, descripcion FROM tipo_servicio WHERE id_tipo_servicio = ?";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                tipo = new TipoServicio();
                tipo.setIdTipoServicio(rs.getInt("id_tipo_servicio"));
                tipo.setDescripcion(rs.getString("descripcion"));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar tipo de servicio por ID: " + e.getMessage());
        }
        return tipo;
    }

    public boolean insertarTipoServicio(TipoServicio tipo) {
        boolean inserto = false;
        String querySql = "INSERT INTO tipo_servicio (descripcion) VALUES (?)";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setString(1, tipo.getDescripcion());

            if (ps.executeUpdate() > 0) {
                inserto = true;
                System.out.println("Tipo de servicio insertado correctamente");
            }
        } catch (SQLException e) {
            System.out.println("Error al insertar tipo de servicio: " + e.getMessage());
        }
        return inserto;
    }

    public boolean actualizarTipoServicio(TipoServicio tipo) {
        boolean actualizo = false;
        String querySql = "UPDATE tipo_servicio SET descripcion = ? WHERE id_tipo_servicio = ?";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setString(1, tipo.getDescripcion());
            ps.setInt(2, tipo.getIdTipoServicio());

            if (ps.executeUpdate() > 0) {
                actualizo = true;
                System.out.println("Tipo de servicio actualizado correctamente");
            }
        } catch (SQLException e) {
            System.out.println("Error al actualizar tipo de servicio: " + e.getMessage());
        }
        return actualizo;
    }

    public boolean eliminarTipoServicio(int id) {
        boolean elimino = false;
        String querySql = "DELETE FROM tipo_servicio WHERE id_tipo_servicio = ?";
        Connection conn = conect.getConn();

        try {
            PreparedStatement ps = conn.prepareStatement(querySql);
            ps.setInt(1, id);

            if (ps.executeUpdate() > 0) {
                elimino = true;
                System.out.println("Tipo de servicio eliminado correctamente");
            }
        } catch (SQLException e) {
            System.out.println("Error al eliminar tipo de servicio: " + e.getMessage());
        }
        return elimino;
    }
}