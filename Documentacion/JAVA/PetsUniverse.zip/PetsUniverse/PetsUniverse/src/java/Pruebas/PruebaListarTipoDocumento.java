/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.List;

public class PruebaListarTipoDocumento {

    public static void main(String[] args) {
        TipoDocumentoDAO dao = new TipoDocumentoDAO();
        List<TipoDocumento> lista = dao.listarTiposDocumento();

        for (TipoDocumento td : lista) {
            System.out.println("ID: " + td.getIdTipoDocumento() + " | Descripcion: " + td.getDescripcion());
        }
    }
}