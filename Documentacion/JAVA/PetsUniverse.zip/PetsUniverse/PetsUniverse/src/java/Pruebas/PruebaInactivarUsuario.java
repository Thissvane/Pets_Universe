/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.Scanner;

public class PruebaInactivarUsuario {

    public static void main(String[] args) {
        Scanner myScan = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();

        System.out.println("Por favor ingrese el usuario a inactivar: ");
        int id = myScan.nextInt();

        if (dao.InactivarUsuario(id)) {
            System.out.println("El usuario fue inactivado con éxito.");
        } else {

            System.out.println("No se encontro el usuario");
        }
        myScan.close();
    }

}
