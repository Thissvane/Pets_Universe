/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Pruebas;

import Controlador.UsuarioDAO;
import java.util.Scanner;

public class PruebaActivarUsuario {

    public static void main(String[] args) {
        Scanner myScan = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();

        System.out.println("Por favor ingrese el usuario a activar: ");
        int id = myScan.nextInt();

        
        if (dao.ActivarUsuario(id)) {
            System.out.println("El usuario fue activado con éxito.");
        } else {
            // Nota: Si el usuario ya estaba activo, el update en SQL puede 
            // afectar 0 filas y devolver false. Esto es normal.
            System.out.println("No se pudo activar. (¿El usuario ya estaba activo o no existe?)");
        }
        
        myScan.close();
    }
}