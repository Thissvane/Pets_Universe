/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.time.LocalDate;
import java.util.Scanner;

public class PruebaActualizarUsuario {

    public static void main(String[] args) {

        Scanner myScan = new Scanner(System.in);
        Usuario miUsuario = new Usuario();
        UsuarioDAO dao = new UsuarioDAO();

        System.out.println("--- PRUEBA DE ACTUALIZACIÓN DE USUARIO ---");

        // Identificador del registro a modificar
        System.out.print("Por favor ingrese el ID del usuario a actualizar: ");
        miUsuario.setIdUsuario(myScan.nextInt());
        myScan.nextLine(); // Limpiar búfer tras nextInt()

        // Datos personales a actualizar
        System.out.print("Por favor ingrese el nombre a actualizar: ");
        miUsuario.setNombre(myScan.nextLine());

        System.out.print("Por favor ingrese el apellido a actualizar: ");
        miUsuario.setApellido(myScan.nextLine());

        System.out.print("Por favor ingrese la fecha de nacimiento (YYYY-MM-DD): ");
        miUsuario.setFechaNacimiento(LocalDate.parse(myScan.nextLine()));

        System.out.print("Por favor ingrese el número de documento: ");
        miUsuario.setNumDocumento(myScan.nextLine());

        System.out.print("Por favor ingrese el número de teléfono: ");
        miUsuario.setNumTelefono(myScan.nextLine());

        System.out.print("Por favor ingrese el email a actualizar: ");
        miUsuario.setEmail(myScan.nextLine());

        System.out.print("Por favor ingrese la nueva clave: ");
        miUsuario.setClave(myScan.nextLine());

        // Claves foráneas y datos de control
        System.out.print("Por favor ingrese el ID del tipo de documento (ej. 1=CC, 2=Pasaporte): ");
        miUsuario.setTipoDocumentoIdTipoDocumento(myScan.nextInt());

        System.out.print("Por favor confirme la autorización de datos (true/false): ");
        miUsuario.setAutorizacionDatos(myScan.nextBoolean());

        // Manejo automático o manual de la fecha de vencimiento de la clave
        // (Aquí mantenemos la lectura manual si deseas probar una fecha específica)
        System.out.print("Por favor ingrese la fecha de vencimiento de la clave (YYYY-MM-DD): ");
        miUsuario.setFechaVencimientoClave(LocalDate.parse(myScan.next()));

        // Para pruebas del DAO se solicita el ID del rol; en el Servlet web este valor no vendrá del usuario final.
        System.out.print("Por favor ingrese el ID del tipo de usuario (Rol): ");
        miUsuario.setTipoUsuarioIdTipoUsuario(myScan.nextInt());

        // Ejecución del método en el DAO
        boolean resultado = dao.ActualizarUsuario(miUsuario);

        if (resultado) {
            System.out.println("\n✓ La actualización se guardó correctamente.");
        } else {
            System.out.println("\n✕ El usuario no se pudo actualizar.");
        }

        myScan.close();
    }
}