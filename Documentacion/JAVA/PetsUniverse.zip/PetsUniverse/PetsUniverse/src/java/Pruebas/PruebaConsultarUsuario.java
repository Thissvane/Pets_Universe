/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;
import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.Scanner;


public class PruebaConsultarUsuario {
    public static void main(String[] args) {
        
        UsuarioDAO miUsuarioDAO = new UsuarioDAO();
       // String correo = "ana.gomez@mail.com";
       
        
        Scanner  leer = new Scanner ((System.in));
        String correo;
        System.out.println("Por favor digite su correo: ");
        correo = leer.next();
        
        Usuario miUsuario  = miUsuarioDAO.consultarUsuario(correo);
         
        if (miUsuario != null) {
        
        System.out.println("Nombre: " + miUsuario.getNombre());
        System.out.println("Apellido: " + miUsuario.getApellido());
        System.out.println("Fecha de Nacimiento: " + miUsuario.getFechaNacimiento());
        System.out.println("Número Documento: " + miUsuario.getNumDocumento());
        System.out.println("Número de Teléfono: " + miUsuario.getNumTelefono());
        System.out.println("Email: " + miUsuario.getEmail());
        System.out.println("Clave: " + miUsuario.getClave());
        System.out.println("fecha Vencimiento Clave: " + miUsuario.getFechaVencimientoClave());
        System.out.println("tipo Documento: " + miUsuario.getTipoDocumentoIdTipoDocumento());
        System.out.println("tipo Usuario: " + miUsuario.getTipoUsuarioIdTipoUsuario());

        } else{
        
        System.out.println("No se encontro el usuario");
        
       
        }
    }
}
