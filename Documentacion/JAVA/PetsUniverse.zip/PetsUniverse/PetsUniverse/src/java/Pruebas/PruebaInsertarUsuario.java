/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.time.LocalDate;
import java.util.Scanner;

public class PruebaInsertarUsuario {

    public static void main(String[] args) {

        Scanner myScan = new Scanner(System.in);
        Usuario miUsuario = new Usuario();
        UsuarioDAO dao = new UsuarioDAO();

        System.out.print("Por favor ingrese su nombre: ");
        miUsuario.setNombre(myScan.nextLine());

        System.out.print("Por favor ingrese su apellido: ");
        miUsuario.setApellido(myScan.nextLine());

        System.out.print("Por favor ingrese su fecha de nacimiento (YYYY-MM-DD): ");
        miUsuario.setFechaNacimiento(LocalDate.parse(myScan.nextLine()));

        System.out.print("Por favor ingrese su número de documento: ");
        miUsuario.setNumDocumento(myScan.nextLine());

        System.out.print("Por favor ingrese su número de teléfono: ");
        miUsuario.setNumTelefono(myScan.nextLine());

        System.out.print("Por favor ingrese su email: ");
        miUsuario.setEmail(myScan.nextLine());

        System.out.print("Por favor ingrese su clave: ");
        miUsuario.setClave(myScan.nextLine());

        System.out.print("Por favor ingrese el ID del tipo de documento (ej. 1=Cédula, 2=Pasaporte): ");
        miUsuario.setTipoDocumentoIdTipoDocumento(myScan.nextInt());

        System.out.print("Por favor confirme su autorización de datos (true/false): ");
        miUsuario.setAutorizacionDatos(myScan.nextBoolean());

        // 2. Datos asignados automáticamente (Reglas de negocio)
        
        // Vencimiento de clave automático a 90 días a partir de hoy
        miUsuario.setFechaVencimientoClave(LocalDate.now().plusDays(90));

        // Asignación de rol por defecto (ejemplo: 2 = Usuario Estándar/Cliente)
        miUsuario.setTipoUsuarioIdTipoUsuario(2);

        // 3. Envío al DAO para persistencia
        boolean resultado = dao.InsertarUsuario(miUsuario);

        if (resultado) {
            System.out.println("El usuario se guardó correctamente.");
        } else {
            System.out.println("El usuario no se pudo registrar.");
        }

        myScan.close();
    }
}