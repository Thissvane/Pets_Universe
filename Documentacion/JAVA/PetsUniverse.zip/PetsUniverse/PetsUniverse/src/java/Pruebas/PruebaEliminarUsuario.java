/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Pruebas;

import Controlador.UsuarioDAO;
import java.util.Scanner;

public class PruebaEliminarUsuario {

    public static void main(String[] args) {
        Scanner myScan = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();

        System.out.println("Por favor ingrese el ID del usuario a eliminar: ");
        int id = myScan.nextInt();

        if (dao.EliminarUsuario(id)) {
            System.out.println("El usuario fue eliminado con éxito de la base de datos.");
        } else {
            System.out.println("No se pudo eliminar el usuario (¿No existe el ID en la BD?).");
        }

        myScan.close();
    }
}