package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebaConsultarTipoDocumento {

    public static void main(String[] args) {
        Scanner myScan = new Scanner(System.in);
        TipoDocumentoDAO dao = new TipoDocumentoDAO();
        
        System.out.print("Ingrese el ID del Tipo de Documento a consultar: ");
        int id = myScan.nextInt();

        TipoDocumento td = dao.consultarTipoDocumentoPorId(id);

        if (td != null) {
            System.out.println("TIPO DE DOCUMENTO ENCONTRADO");
            System.out.println("ID: " + td.getIdTipoDocumento());
            System.out.println("Sigla: " + td.getSigla());
            System.out.println("Descripción: " + td.getDescripcion());
        } else {
            System.out.println("No se encontró el tipo de documento con el ID: " + id);
        }

        myScan.close();
    }
}